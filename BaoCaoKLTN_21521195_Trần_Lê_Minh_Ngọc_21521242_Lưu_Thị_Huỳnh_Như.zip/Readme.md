# InsecLab Thesis Template

## Notes

- Nhớ dùng `\bigbreak\noindent` giữa các đoạn văn :v

## Tối ưu

[Overleaf đã thay đổi về thời gian compile của free plan](https://www.overleaf.com/blog/changes-to-free-compile-timeouts-and-servers), để có thể tránh gặp phải trường hợp timeout, sau đây là một số tip:

- Tối ưu dung lượng ảnh sử dụng các website như [Squoosh](https://squoosh.app) hay [image-compress](https://www.webutils.app/image-compress) (Latex chỉ cho phép các dạng ảnh như jpg hoặc png, lưu ý khi chuyển đổi định dạng).
- Chỉ thêm các cite cần thiết vào trong file `references.bib`.
- Mua bản pro :D hoặc compile offline.
